import SwiftUI
import UIKit

// MARK: - Model

struct Game: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var folder: String      // folder name inside Documents/games
    var bytes: Int64
    var fileCount: Int
    var added: Date

    var url: URL { Paths.games.appendingPathComponent(folder, isDirectory: true) }
}

enum Paths {
    static let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    static let games = docs.appendingPathComponent("games", isDirectory: true)
    static let index = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("library.json")
}

// MARK: - Engine hook (plug the real game runtime in here)

protocol GameEngine {
    /// Start the game whose imported data is in `folder`.
    func launch(folder: URL) throws
}

enum Engine {
    /// Set this at app start once a runtime is linked into the app. Nil = no runtime yet.
    static var current: GameEngine?
}

// MARK: - Importer

enum ImportError: LocalizedError {
    case noSpace(need: Int64, free: Int64)
    case sizeMismatch(String)

    var errorDescription: String? {
        let f = { (n: Int64) in ByteCountFormatter.string(fromByteCount: n, countStyle: .file) }
        switch self {
        case .noSpace(let need, let free): return "Not enough space: this needs \(f(need)) and the iPhone has \(f(free)) free."
        case .sizeMismatch(let name): return "\"\(name)\" did not copy completely. Make sure the file is downloaded (not only in iCloud) and try again."
        }
    }
}

final class CancelFlag: @unchecked Sendable {
    private let lock = NSLock()
    private var flag = false
    var isSet: Bool { lock.lock(); defer { lock.unlock() }; return flag }
    func set() { lock.lock(); flag = true; lock.unlock() }
}

enum Importer {
    struct Item { var from: URL; var rel: String; var size: Int64 }
    struct Outcome { var bytes: Int64; var files: Int }

    static func isDirectory(_ u: URL) -> Bool {
        (try? u.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
    }

    private static func scan(_ dir: URL, _ rel: String, _ out: inout [Item]) throws {
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey]
        let kids = try FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles])
        for u in kids {
            let v = try u.resourceValues(forKeys: Set(keys))
            let r = rel.isEmpty ? u.lastPathComponent : rel + "/" + u.lastPathComponent
            if v.isDirectory == true { try scan(u, r, &out) }
            else { out.append(Item(from: u, rel: r, size: Int64(v.fileSize ?? 0))) }
        }
    }

    /// Copies the picked folder(s)/file(s) into `dest`, reports (done, total) bytes, then checks every file's size.
    static func copy(_ sources: [URL], to dest: URL, cancelled: () -> Bool, progress: (Int64, Int64) -> Void) throws -> Outcome {
        let fm = FileManager.default
        var items: [Item] = []
        if sources.count == 1, isDirectory(sources[0]) {
            try scan(sources[0], "", &items)
        } else {
            for s in sources {
                if isDirectory(s) { try scan(s, s.lastPathComponent, &items) }
                else { items.append(Item(from: s, rel: s.lastPathComponent, size: Int64((try? s.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0))) }
            }
        }
        let total = items.reduce(Int64(0)) { $0 + $1.size }

        try fm.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
        let free = (try? dest.deletingLastPathComponent().resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]))?
            .volumeAvailableCapacityForImportantUsage ?? Int64.max
        if free < total + (256 << 20) { throw ImportError.noSpace(need: total, free: free) }

        do {
            try fm.createDirectory(at: dest, withIntermediateDirectories: true)
            progress(0, total)
            var done: Int64 = 0, last: Int64 = 0
            for it in items {
                try copyFile(it.from, dest.appendingPathComponent(it.rel), cancelled: cancelled) { n in
                    done += n
                    if done - last >= (8 << 20) { last = done; progress(done, total) }
                }
            }
            progress(total, total)
            for it in items {   // check that everything arrived whole
                let path = dest.appendingPathComponent(it.rel).path
                let got = (try fm.attributesOfItem(atPath: path)[.size] as? NSNumber)?.int64Value ?? -1
                if got != it.size { throw ImportError.sizeMismatch(it.rel) }
            }
            var d = dest
            var rv = URLResourceValues(); rv.isExcludedFromBackup = true   // big data: keep it out of iCloud backups
            try? d.setResourceValues(rv)
            return Outcome(bytes: total, files: items.count)
        } catch {
            try? fm.removeItem(at: dest)
            throw error
        }
    }

    private static func copyFile(_ src: URL, _ dst: URL, cancelled: () -> Bool, bump: (Int64) -> Void) throws {
        let fm = FileManager.default
        try fm.createDirectory(at: dst.deletingLastPathComponent(), withIntermediateDirectories: true)
        fm.createFile(atPath: dst.path, contents: nil)
        let r = try FileHandle(forReadingFrom: src)
        let w = try FileHandle(forWritingTo: dst)
        defer { try? r.close(); try? w.close() }
        while true {
            if cancelled() { throw CancellationError() }
            let chunk = try autoreleasepool { try r.read(upToCount: 8 << 20) }
            guard let c = chunk, !c.isEmpty else { break }
            try w.write(contentsOf: c)
            bump(Int64(c.count))
        }
    }
}

// MARK: - Library store

@MainActor
final class Library: ObservableObject {
    struct Job { var title: String; var done: Int64 = 0; var total: Int64 = 0 }

    @Published private(set) var games: [Game] = []
    @Published private(set) var job: Job? {
        didSet { UIApplication.shared.isIdleTimerDisabled = (job != nil) }   // keep the screen awake while copying
    }
    @Published var errorText: String?

    private var cancel = CancelFlag()

    init() { load() }

    // persistence
    private func load() {
        guard let data = try? Data(contentsOf: Paths.index),
              let list = try? JSONDecoder().decode([Game].self, from: data) else { return }
        games = list.filter { FileManager.default.fileExists(atPath: $0.url.path) }
    }
    private func save() {
        try? FileManager.default.createDirectory(at: Paths.index.deletingLastPathComponent(), withIntermediateDirectories: true)
        try? JSONEncoder().encode(games).write(to: Paths.index, options: .atomic)
    }

    // adding
    func add(_ urls: [URL]) {
        guard job == nil, !urls.isEmpty else { return }
        cancel = CancelFlag()
        let scoped = urls.filter { $0.startAccessingSecurityScopedResource() }   // needed before the folder check
        defer { scoped.forEach { $0.stopAccessingSecurityScopedResource() } }
        // every picked folder is one game; all picked loose files together are one game
        var groups: [[URL]] = urls.filter { Importer.isDirectory($0) }.map { [$0] }
        let files = urls.filter { !Importer.isDirectory($0) }
        if !files.isEmpty { groups.append(files) }
        Task { for g in groups { await importGroup(g); if cancel.isSet { break } }; job = nil }
    }

    func cancelImport() { cancel.set() }

    private func uniqueFolder(_ base: String) -> String {
        let clean = base.replacingOccurrences(of: "/", with: "-")
        var name = clean.isEmpty ? "Game" : clean, n = 2
        while FileManager.default.fileExists(atPath: Paths.games.appendingPathComponent(name).path) { name = "\(clean) \(n)"; n += 1 }
        return name
    }

    private func importGroup(_ sources: [URL]) async {
        let scoped = sources.filter { $0.startAccessingSecurityScopedResource() }
        defer { scoped.forEach { $0.stopAccessingSecurityScopedResource() } }

        let first = sources[0]
        let name = Importer.isDirectory(first) ? first.lastPathComponent : first.deletingPathExtension().lastPathComponent
        let folder = uniqueFolder(name)
        let dest = Paths.games.appendingPathComponent(folder, isDirectory: true)
        job = Job(title: name)

        let flag = cancel
        let me = self
        let result: Result<Importer.Outcome, Error> = await Task.detached(priority: .userInitiated) { () -> Result<Importer.Outcome, Error> in
            do {
                let o = try Importer.copy(sources, to: dest, cancelled: { flag.isSet }) { done, total in
                    Task { @MainActor in
                        me.job?.done = max(me.job?.done ?? 0, done)
                        me.job?.total = total
                    }
                }
                return .success(o)
            } catch { return .failure(error) }
        }.value

        switch result {
        case .success(let o):
            games.append(Game(name: name, folder: folder, bytes: o.bytes, fileCount: o.files, added: Date()))
            save()
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        case .failure(let e):
            if !(e is CancellationError) { errorText = e.localizedDescription }
        }
    }

    // removing / playing
    func remove(_ g: Game) {
        try? FileManager.default.removeItem(at: g.url)
        games.removeAll { $0.id == g.id }
        save()
    }

    func play(_ g: Game) {
        guard let engine = Engine.current else {
            errorText = "The data for \"\(g.name)\" is imported and ready, but no game runtime is linked into this build yet. See README → Linking a runtime."
            return
        }
        do { try engine.launch(folder: g.url) } catch { errorText = error.localizedDescription }
    }
}
