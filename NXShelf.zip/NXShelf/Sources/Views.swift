import SwiftUI
import UIKit
import UniformTypeIdentifiers

// MARK: - Look (the dark-blue palette from HookLink's launcher)

enum Theme {
    static let teal = Color(red: 0.56, green: 0.90, blue: 0.84)
    static let dim = Color(red: 0.66, green: 0.73, blue: 0.92)
    static let line = Color(red: 0.45, green: 0.54, blue: 0.80)
    static let sky = LinearGradient(
        colors: [Color(red: 0, green: 0, blue: 0.016), Color(red: 0.008, green: 0.016, blue: 0.10),
                 Color(red: 0.04, green: 0.10, blue: 0.43), Color(red: 0.07, green: 0.19, blue: 0.66)],
        startPoint: .top, endPoint: .bottom)
}

func sizeText(_ n: Int64) -> String { ByteCountFormatter.string(fromByteCount: n, countStyle: .file) }

// MARK: - Main screen

struct ContentView: View {
    @EnvironmentObject var lib: Library
    @State private var showImporter = false
    @State private var pickFolder = true
    @State private var selected: Game?

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.sky.ignoresSafeArea()
                if lib.games.isEmpty && lib.job == nil {
                    EmptyState { pickFolder = true; showImporter = true }
                } else {
                    ScrollView {
                        VStack(spacing: 14) {
                            if let job = lib.job { ProgressCard(job: job) { lib.cancelImport() } }
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 300), spacing: 14)], spacing: 14) {
                                ForEach(lib.games) { g in
                                    Button { selected = g } label: { GameCard(game: g) }.buttonStyle(.plain)
                                }
                            }
                        }
                        .padding(16)
                    }
                }
            }
            .navigationTitle("Library")
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button { pickFolder = true; showImporter = true } label: { Label("Add Game Folder", systemImage: "folder.badge.plus") }
                        Button { pickFolder = false; showImporter = true } label: { Label("Add Game Files", systemImage: "doc.badge.plus") }
                    } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 17, weight: .bold))
                            .foregroundStyle(Theme.teal)
                            .frame(width: 36, height: 36)
                            .background(Circle().fill(.white.opacity(0.12)))
                            .overlay(Circle().stroke(Theme.line, lineWidth: 1))
                    }
                    .disabled(lib.job != nil)
                    .accessibilityLabel("Add game data")
                }
            }
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: pickFolder ? [.folder] : [.item],
                      allowsMultipleSelection: !pickFolder) { result in
            switch result {
            case .success(let urls): lib.add(urls)
            case .failure(let e): lib.errorText = e.localizedDescription
            }
        }
        .sheet(item: $selected) { g in GameSheet(game: g).environmentObject(lib) }
        .alert("Heads up", isPresented: Binding(get: { lib.errorText != nil }, set: { if !$0 { lib.errorText = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(lib.errorText ?? "") }
    }
}

// MARK: - Pieces

struct EmptyState: View {
    var add: () -> Void
    var body: some View {
        VStack(spacing: 18) {
            Button(action: add) {
                Image(systemName: "plus")
                    .font(.system(size: 44, weight: .bold))
                    .foregroundStyle(Theme.teal)
                    .frame(width: 112, height: 112)
                    .background(Circle().fill(.white.opacity(0.10)))
                    .overlay(Circle().stroke(Theme.line, lineWidth: 1.5))
            }
            Text("Add your game data").font(.title2.weight(.bold)).foregroundStyle(.white)
            Text("Tap + and pick the folder (or files) with your own game data from the Files app.")
                .font(.subheadline).foregroundStyle(Theme.dim).multilineTextAlignment(.center).padding(.horizontal, 40)
        }
    }
}

struct GameCard: View {
    let game: Game
    private var hue: Double {
        Double(game.name.unicodeScalars.reduce(0) { ($0 * 31 + Int($1.value)) % 360 }) / 360
    }
    private var initials: String {
        let w = game.name.split(separator: " ").prefix(2).compactMap { $0.first }
        return String(w).uppercased()
    }
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            LinearGradient(colors: [Color(hue: hue, saturation: 0.55, brightness: 0.55),
                                    Color(hue: hue, saturation: 0.75, brightness: 0.25)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            Text(initials).font(.system(size: 64, weight: .heavy, design: .rounded))
                .foregroundStyle(.white.opacity(0.18)).frame(maxWidth: .infinity, maxHeight: .infinity)
            VStack(alignment: .leading, spacing: 2) {
                Text(game.name).font(.headline).foregroundStyle(.white).lineLimit(2)
                Text("\(sizeText(game.bytes)) · \(game.fileCount) file\(game.fileCount == 1 ? "" : "s")")
                    .font(.caption).foregroundStyle(Theme.dim)
            }
            .padding(12).frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [.clear, .black.opacity(0.6)], startPoint: .top, endPoint: .bottom))
        }
        .aspectRatio(16 / 9, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Theme.line.opacity(0.7), lineWidth: 1))
    }
}

struct ProgressCard: View {
    let job: Library.Job
    var cancel: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Adding \(job.title)").font(.headline).foregroundStyle(.white).lineLimit(1)
                Spacer()
                Button("Cancel", action: cancel).font(.subheadline.weight(.semibold)).foregroundStyle(Theme.teal)
            }
            ProgressView(value: Double(job.done), total: Double(max(job.total, 1))).tint(Theme.teal)
            Text("\(sizeText(job.done)) of \(sizeText(job.total)) · keep the app open").font(.caption).foregroundStyle(Theme.dim)
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(.white.opacity(0.08)))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Theme.line.opacity(0.7), lineWidth: 1))
    }
}

struct GameSheet: View {
    let game: Game
    @EnvironmentObject var lib: Library
    @Environment(\.dismiss) private var dismiss
    @State private var confirmRemove = false

    var body: some View {
        ZStack {
            Theme.sky.ignoresSafeArea()
            VStack(spacing: 16) {
                GameCard(game: game)
                VStack(alignment: .leading, spacing: 6) {
                    row("Size", sizeText(game.bytes))
                    row("Files", "\(game.fileCount)")
                    row("Added", game.added.formatted(date: .abbreviated, time: .shortened))
                    row("Location", "On My iPhone › NX Shelf › games › \(game.folder)")
                }
                .padding(14).frame(maxWidth: .infinity, alignment: .leading)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(.white.opacity(0.08)))

                Button {
                    dismiss()
                    Task { @MainActor in try? await Task.sleep(nanoseconds: 400_000_000); lib.play(game) }   // let the sheet close before any alert
                } label: {
                    Label("Play", systemImage: "play.fill").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 14)
                }
                .buttonStyle(.borderedProminent).tint(Theme.teal).foregroundStyle(.black)

                Button {
                    if let u = URL(string: "shareddocuments://" + Paths.games.path) { UIApplication.shared.open(u) }
                } label: { Label("Show in Files", systemImage: "folder").frame(maxWidth: .infinity) }
                .buttonStyle(.bordered).tint(Theme.teal)

                Button(role: .destructive) { confirmRemove = true } label: {
                    Label("Remove from this iPhone", systemImage: "trash").frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                Spacer()
            }
            .padding(20)
        }
        .presentationDetents([.large])
        .confirmationDialog("Remove \"\(game.name)\"? This deletes its data from this iPhone.", isPresented: $confirmRemove, titleVisibility: .visible) {
            Button("Remove", role: .destructive) { dismiss(); lib.remove(game) }
        }
    }

    private func row(_ k: String, _ v: String) -> some View {
        HStack(alignment: .top) {
            Text(k).foregroundStyle(Theme.dim).frame(width: 78, alignment: .leading)
            Text(v).foregroundStyle(.white)
            Spacer(minLength: 0)
        }.font(.subheadline)
    }
}
