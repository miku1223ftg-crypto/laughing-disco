# NX Shelf: iPhone library app

An iPhone app with a **+** at the top of the screen. Tap it, pick the folder (or files) that hold your own
game data in the Files app, and the app copies them into its own storage with a progress bar, checks that
every file arrived whole, and shows the game as a card in your library.

- **+ (top right):** Add Game Folder / Add Game Files
- **Library:** one card per game, with its size and file count
- **Card:** Play, Show in Files, Remove
- **Where the data goes:** `Documents/games/<name>/`, visible in Files > On My iPhone > NX Shelf > games

## Get the IPA without a Mac (from Windows 11)

1. Create a **private** repository on GitHub and upload everything in this folder (keep `.github/`).
2. Open the **Actions** tab > **Build IPA** > **Run workflow**. It builds on a GitHub Mac (a few minutes).
3. Open the finished run and download the **NXShelf-ipa** artifact (a zip holding `NXShelf.ipa`).
4. Install it on your iPhone with Sideloadly (Windows) or AltStore. If your tool offers
   **Increased Memory Limit**, turn it on.

The IPA is unsigned on purpose: your sideloading tool signs it with your Apple ID. If you have a Mac,
`brew install xcodegen && xcodegen generate` and open `NXShelf.xcodeproj` in Xcode instead.

## Linking a runtime (what Play does)

This app only imports and organises game data. **Play** calls `Engine.current`, which is empty until you
link a runtime into the app (see `protocol GameEngine` in `Sources/Library.swift`). Until then Play says so.
The runtime itself (for example the NX 18 / NX2Apple iPhone shell) is built separately.

## Notes

- Keep the app open while a big game copies; the screen stays awake during the copy.
- Files that live only in iCloud Drive must be downloaded first (Files > Keep Downloaded), or the copy
  stops with a "did not copy completely" message.
- The copy needs free space equal to the data's size plus a little extra.
- Change `PRODUCT_BUNDLE_IDENTIFIER` in `project.yml` if you want your own.
